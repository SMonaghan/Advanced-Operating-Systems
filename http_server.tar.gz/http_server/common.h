#ifndef COMMON_H
#define COMMON_H

char messages[32][129];
char messages_head[32][257];

#endif
